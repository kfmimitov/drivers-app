﻿app.controller("UploadController", [
    "$scope", "driversService", "$state", "$stateParams",
    function ($scope, driversService, $state, $stateParams) {

        $scope.selectedPicture = "data:image/jpeg;base64," + driversService.getPhotoToUpload();


    }]);